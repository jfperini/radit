/*
	BASSenc recording example
	Copyright (c) 2003-2009 Un4seen Developments Ltd.
*/

#include <gtk/gtk.h>
#include <glade/glade.h>
#include "bass.h"
#include "bassenc.h"

// path to glade file
#ifndef GLADE_PATH
#define GLADE_PATH ""
#endif

GladeXML *glade;
GtkWidget *win=0;

int input;				// current input source
int encoder;			// current encoder

HRECORD rchan=0;		// recording channel
HSTREAM chan=0;			// playback channel

// encoder command-lines and output files
const char *commands[3]={
	"bass.wav", // no encoder (WAV)
	"oggenc -o bass.ogg -", // oggenc (OGG)
	"lame --alt-preset standard - bass.mp3", // lame (MP3)
};
const char *files[3]={"bass.wav","bass.ogg","bass.mp3"};

// display error messages
void Error(const char *es)
{
	GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"%s\n(error code: %d)",es,BASS_ErrorGetCode());
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

#define GetWidget(id) glade_xml_get_widget(glade,id)

void WindowDestroy(GtkObject *obj, gpointer data)
{
	gtk_main_quit();
}

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void StartRecording()
{
	if (chan) { // free old recording
		BASS_StreamFree(chan);
		chan=0;
		gtk_widget_set_sensitive(GetWidget("play"),FALSE);
	}
	// start recording @ 44100hz 16-bit stereo (paused to add encoder first)
	if (!(rchan=BASS_RecordStart(44100,2, BASS_RECORD_PAUSE,&RecordingCallback,0))) {
		Error("Couldn't start recording");
		return;
	}
	// get selected encoder (0=WAV, 1=OGG, 2=MP3)
	if (GTK_TOGGLE_BUTTON(GetWidget("wav"))->active) encoder=0;
	else if (GTK_TOGGLE_BUTTON(GetWidget("ogg"))->active) encoder=1;
	else encoder=2;
	if (!BASS_Encode_Start(rchan,commands[encoder],(encoder?0:BASS_ENCODE_PCM)|BASS_ENCODE_AUTOFREE,NULL,0)) { // start encoding
		Error("Couldn't start encoding...\n"
			"Make sure OGGENC (if encoding to OGG) or LAME (if encoding to MP3) is installed.\n");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	BASS_ChannelPlay(rchan,FALSE); // resume recoding
	gtk_button_set_label(GTK_BUTTON(GetWidget("record")),"Stop");
}

void StopRecording()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan=0;
	// create a stream from the recording
	if (chan=BASS_StreamCreateFile(FALSE,files[encoder],0,0,0))
		gtk_widget_set_sensitive(GetWidget("play"),TRUE); // enable "play" button
	gtk_button_set_label(GTK_BUTTON(GetWidget("record")),"Record");
}

void UpdateInputInfo()
{
	float level;
	BASS_RecordGetInput(input,&level); // get info on the input
	gtk_range_set_value(GTK_RANGE(GetWidget("level")),level*100); // set the level slider
}

void RecordClicked(GtkButton *obj, gpointer data)
{
	if (!rchan)
		StartRecording();
	else
		StopRecording();
}

void PlayClicked(GtkButton *obj, gpointer data)
{
	BASS_ChannelPlay(chan,TRUE); // play the recorded data
}

void InputChanged(GtkComboBox *obj, gpointer data)
{
	int i;
	input=gtk_combo_box_get_active(obj); // get the selection
	// enable the selected input
	for (i=0;BASS_RecordSetInput(i,BASS_INPUT_OFF,-1);i++) ; // 1st disable all inputs, then...
	BASS_RecordSetInput(input,BASS_INPUT_ON,-1); // enable the selected
	UpdateInputInfo(); // update info
}

void LevelChanged(GtkRange *range, gpointer data)
{
	double level=gtk_range_get_value(range)/100;
	if (!BASS_RecordSetInput(input,0,level)) // failed to set input level
		BASS_RecordSetInput(-1,0,level); // try master level instead
}

gboolean TimerProc(gpointer data)
{ // update the recording/playback counter
	char text[30]="";
	if (rchan) // recording
		sprintf(text,"%llu",BASS_ChannelGetPosition(rchan,BASS_POS_BYTE));
	else if (chan) {
		if (BASS_ChannelIsActive(chan)) // playing
			sprintf(text,"%llu / %llu",BASS_ChannelGetPosition(chan,BASS_POS_BYTE),BASS_ChannelGetLength(chan,BASS_POS_BYTE));
		else
			sprintf(text,"%llu",BASS_ChannelGetLength(chan,BASS_POS_BYTE));
	}
	gtk_label_set(GTK_LABEL(GetWidget("status")),text);
	return TRUE;
}

int main(int argc, char* argv[])
{
	gtk_init(&argc,&argv);

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		Error("An incorrect version of BASS was loaded");
		return 0;
	}

	// initialize recording and output devices (using default devices)
	if (!BASS_RecordInit(-1) || !BASS_Init(-1,44100,0,NULL,NULL)) {
		Error("Can't initialize device");
		return 0;
	}

	// initialize GUI
	glade=glade_xml_new(GLADE_PATH"rectest.glade",NULL,NULL);
	if (!glade) return 0;
	win=GetWidget("window1");
	if (!win) return 0;
	glade_xml_signal_autoconnect(glade);

	{ // get list of inputs
		int c;
		const char *i;
		GtkComboBox *list=GTK_COMBO_BOX(GetWidget("input"));
		for (c=0;i=BASS_RecordGetInputName(c);c++) {
			gtk_combo_box_append_text(list,i);
			if (!(BASS_RecordGetInput(c,NULL)&BASS_INPUT_OFF)) { // this 1 is currently "on"
				input=c;
				gtk_combo_box_set_active(list,input);
				UpdateInputInfo(); // display info
			}
		}
	}

	g_timeout_add(200,TimerProc,NULL);

	gtk_main();

	// release all BASS stuff
	BASS_RecordFree();
	BASS_Free();

    return 0;
}
