/*
	BASSenc server example
	Copyright (c) 2011-2013 Un4seen Developments Ltd.
*/

#include <gtk/gtk.h>
#include <glade/glade.h>
#include <glib/gthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "bass.h"
#include "bassenc.h"

// path to glade file
#ifndef GLADE_PATH
#define GLADE_PATH ""
#endif

GladeXML *glade;
GtkWidget *win=0;

HRECORD rchan=0;	// recording/encoding channel
HENCODE encoder;

DWORD bitrates[14]={32,40,48,56,64,80,96,112,128,160,192,224,256,320}; // available bitrates

// display error messages
void Error(const char *es)
{
	GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"%s\n(error code: %d)",es,BASS_ErrorGetCode());
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

#define GetWidget(id) glade_xml_get_widget(glade,id)

void WindowDestroy(GtkObject *obj, gpointer data)
{
	gtk_main_quit();
}

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void Start();
void Stop();

// encoder death notification
void CALLBACK EncoderNotify(HENCODE handle, DWORD status, void *user)
{
	if (status<0x10000) { // encoder died
		gdk_threads_enter();
		Stop(); // free the recording and encoder
		GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
			GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"The encoder died!");
		gtk_dialog_run(GTK_DIALOG(dialog));
		gtk_widget_destroy(dialog);
		gdk_threads_leave();
	}
}

// client connection/disconnection notification
BOOL CALLBACK EncodeClientProc(HENCODE handle, BOOL connect, const char *client, char *headers, void *user)
{
	if (connect) {
		// build response headers
		char *p=headers;
		const char *name,*url,*genre;
		p+=sprintf(p,"Content-Type: %s\r\n",GTK_TOGGLE_BUTTON(GetWidget("mp3"))->active?BASS_ENCODE_TYPE_MP3:BASS_ENCODE_TYPE_OGG);
		name=gtk_entry_get_text(GTK_ENTRY(GetWidget("name")));
		url=gtk_entry_get_text(GTK_ENTRY(GetWidget("url")));
		genre=gtk_entry_get_text(GTK_ENTRY(GetWidget("genre")));
		if (strlen(name)) p+=sprintf(p,"icy-name:%s\r\n",name);
		if (strlen(url)) p+=sprintf(p,"icy-url:%s\r\n",url);
		if (strlen(genre)) p+=sprintf(p,"icy-genre:%s\r\n",genre);
		{ // add to client list
			GtkListStore *tm=GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(GetWidget("clients"))));
			GtkTreeIter it;
			gtk_list_store_append(tm,&it);
			gtk_list_store_set(tm,&it,0,client,-1);
		}
	} else { // disconnecting, remove from client list
		GtkTreeModel *tm=gtk_tree_view_get_model(GTK_TREE_VIEW(GetWidget("clients")));
		GtkTreeIter it;
		if (gtk_tree_model_get_iter_first(tm,&it)) {
			do {
				char *text;
				gtk_tree_model_get(tm,&it,0,&text,-1);
				if (!strcmp(client,text)) {
					g_free(text);
					gtk_list_store_remove(GTK_LIST_STORE(tm),&it);
					break;
				}
				g_free(text);
			} while (gtk_tree_model_iter_next(tm,&it));
		}
	}
	return TRUE; // allow connectiom
}

void Start()
{
	char buf[100];
	const char *server;
	DWORD bitrate,port;
	// start recording @ 44100hz 16-bit stereo (paused to setup encoder first)
	if (!(rchan=BASS_RecordStart(44100,2,BASS_RECORD_PAUSE,&RecordingCallback,0))) {
		Error("Couldn't start recording");
		return;
	}
	bitrate=bitrates[gtk_combo_box_get_active(GTK_COMBO_BOX(GetWidget("bitrate")))]; // get bitrate
	// setup encoder command-line (raw PCM data to avoid length limit)
	if (GTK_TOGGLE_BUTTON(GetWidget("mp3"))->active) { // MP3
		sprintf(buf,"lame -r -s 44100 -b %d -",bitrate); // add "-x" for LAME versions pre-3.98
	} else if (GTK_TOGGLE_BUTTON(GetWidget("ogg"))->active) { // OGG
		sprintf(buf,"oggenc -r -R 44100 -M %d -m %d -",bitrate,bitrate);
	} else { // FLAC
		sprintf(buf,"flac --ogg --sample-rate=44100 --channels=2 --bps=16 --endian=little --sign=signed -");
		bitrate=706; // assuming 50% reduction
	}
	encoder=BASS_Encode_Start(rchan,buf,BASS_ENCODE_NOHEAD|BASS_ENCODE_AUTOFREE,NULL,0); // start the encoder
	if (!encoder) { // failed
		Error("Couldn't start encoding...\n"
			"Make sure LAME, OGGENC or FLAC is installed.\n");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	server=gtk_entry_get_text(GTK_ENTRY(GetWidget("server")));
	port=BASS_Encode_ServerInit(encoder,server,bitrate*125,-1,0,EncodeClientProc,0); // start the server (5 second buffer, burst the full amount)
	if (!port) { // failed
		Error("Couldn't start server");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	BASS_ChannelPlay(rchan,FALSE); // resume recording
	{ // update port number in display
		strcpy(buf,server);
		char *p=strchr(buf,':');
		if (!p && strchr(buf,'.')) {
			strcat(buf,":");
			p=strchr(buf,':');
		}
		sprintf(p?p+1:buf,"%d",port);
		gtk_entry_set_text(GTK_ENTRY(GetWidget("server")),buf);
	}
	gtk_button_set_label(GTK_BUTTON(GetWidget("start")),"Stop");
	gtk_widget_set_sensitive(GetWidget("server"),FALSE);
	gtk_widget_set_sensitive(GetWidget("name"),FALSE);
	gtk_widget_set_sensitive(GetWidget("url"),FALSE);
	gtk_widget_set_sensitive(GetWidget("genre"),FALSE);
	gtk_widget_set_sensitive(GetWidget("mp3"),FALSE);
	gtk_widget_set_sensitive(GetWidget("ogg"),FALSE);
	gtk_widget_set_sensitive(GetWidget("flac"),FALSE);
	gtk_widget_set_sensitive(GetWidget("bitrate"),FALSE);
	BASS_Encode_SetNotify(encoder,EncoderNotify,0); // notify of dead encoder
}

void Stop()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan=0;
	gtk_button_set_label(GTK_BUTTON(GetWidget("start")),"Start");
	gtk_widget_set_sensitive(GetWidget("server"),TRUE);
	gtk_widget_set_sensitive(GetWidget("name"),TRUE);
	gtk_widget_set_sensitive(GetWidget("url"),TRUE);
	gtk_widget_set_sensitive(GetWidget("genre"),TRUE);
	gtk_widget_set_sensitive(GetWidget("mp3"),TRUE);
	gtk_widget_set_sensitive(GetWidget("ogg"),TRUE);
	gtk_widget_set_sensitive(GetWidget("flac"),TRUE);
	gtk_widget_set_sensitive(GetWidget("bitrate"),TRUE);
	gtk_list_store_clear(GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(GetWidget("clients")))));
}

void StartClicked(GtkButton *obj, gpointer data)
{
	if (!rchan)
		Start();
	else
		Stop();
}

void ClientsActivated(GtkTreeView *obj, GtkTreePath *path, GtkTreeViewColumn *column, gpointer data)
{
	GtkTreeModel *tm=gtk_tree_view_get_model(obj);
	GtkTreeIter it;
	if (gtk_tree_model_get_iter(tm,&it,path)) {
		char *client;
		gtk_tree_model_get(tm,&it,0,&client,-1);
		BASS_Encode_ServerKick(encoder,client);  // kick the selected client
		g_free(client);
	}
}
gboolean TimerProc(gpointer data)
{
	// draw the level bar
	static DWORD level=0;
	level=level>1500?level-1500:0;
	if (rchan) {
		DWORD l=BASS_ChannelGetLevel(rchan); // get current level
		if (LOWORD(l)>level) level=LOWORD(l);
		if (HIWORD(l)>level) level=HIWORD(l);
	}
	gtk_progress_set_percentage(GTK_PROGRESS(GetWidget("level")),level/32768.0);
	return TRUE;
}

int main(int argc, char* argv[])
{
	g_thread_init(NULL);
	gdk_threads_init();
	gtk_init(&argc,&argv);

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		Error("An incorrect version of BASS was loaded");
		return 0;
	}

	// initialize default recording device
	if (!BASS_RecordInit(-1)) {
		Error("Can't initialize device");
		return 0;
	}

	// initialize GUI
	glade=glade_xml_new(GLADE_PATH"server.glade",NULL,NULL);
	if (!glade) return 0;
	win=GetWidget("window1");
	if (!win) return 0;
	glade_xml_signal_autoconnect(glade);

	{
		GtkComboBox *list=GTK_COMBO_BOX(GetWidget("bitrate"));
		int c;
		for (c=0;c<14;c++) {
			char temp[10];
			sprintf(temp,"%d",bitrates[c]);
			gtk_combo_box_append_text(list,temp);
		}
		gtk_combo_box_set_active(list,8); // default bitrate = 128kbps
	}
	{ // setup client list
		GtkTreeView *list=GTK_TREE_VIEW(GetWidget("clients"));
		GtkTreeViewColumn *col=gtk_tree_view_column_new();
		gtk_tree_view_append_column(list,col);
		GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
		gtk_tree_view_column_pack_start(col,renderer,TRUE);
		gtk_tree_view_column_add_attribute(col,renderer,"text",0);
		GtkListStore *liststore=gtk_list_store_new(1,G_TYPE_STRING);
		gtk_tree_view_set_model(list,GTK_TREE_MODEL(liststore));
		g_object_unref(liststore);
	}

	g_timeout_add(50,TimerProc,NULL);

	gdk_threads_enter();
	gtk_main();
	gdk_threads_leave();

	// release all BASS stuff
	BASS_RecordFree();

    return 0;
}
